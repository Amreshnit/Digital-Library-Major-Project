﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_MyAccount : System.Web.UI.Page
{
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();

    System.Data.SqlClient.SqlCommand cmd = new SqlCommand();
    System.Data.SqlClient.SqlDataReader dr;
    DataSet ds;
    System.Data.SqlClient.SqlDataAdapter da;
    string SID, PrevPass;
    System.Data.SqlClient.SqlConnection SQLConn = new System.Data.SqlClient.SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {         
            MultiView1.ActiveViewIndex = 0;
            SDT = SAdapter.Select_By_SID(Convert.ToInt32(Session["sid"].ToString()));
            lblnam.Text = SDT.Rows[0]["Studentname"].ToString();
            lblmobile.Text = SDT.Rows[0]["mobile"].ToString();
            lbladd.Text = SDT.Rows[0]["address"].ToString();
            lblcity.Text = SDT.Rows[0]["city"].ToString();
            lblpincode.Text = SDT.Rows[0]["pincode"].ToString();
            lblemail.Text = SDT.Rows[0]["email"].ToString();

            (Page.Master.FindControl("btnAccount") as Button).Enabled = false;
            (Page.Master.FindControl("btnAccount") as Button).BackColor = System.Drawing.Color.DarkOrange;
        }

    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
        SDT = SAdapter.Select_By_SID(Convert.ToInt32(Session["sid"].ToString()));
        lblnam.Text = SDT.Rows[0]["Studentname"].ToString();
        lblmobile.Text = SDT.Rows[0]["mobile"].ToString();
        lbladd.Text = SDT.Rows[0]["address"].ToString();
        lblcity.Text = SDT.Rows[0]["city"].ToString();
        lblpincode.Text = SDT.Rows[0]["pincode"].ToString();
        lblemail.Text = SDT.Rows[0]["email"].ToString();

    }
    protected void Button13_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
        SDT = SAdapter.Select_By_SID(Convert.ToInt32(Session["sid"].ToString()));
        txtname.Text = SDT.Rows[0]["Studentname"].ToString();
        txtMobile.Text = SDT.Rows[0]["mobile"].ToString();
        txtAddress.Text = SDT.Rows[0]["address"].ToString();
        txtCity.Text = SDT.Rows[0]["city"].ToString();
        txtPIN.Text = SDT.Rows[0]["pincode"].ToString();
        txtEmail.Text = SDT.Rows[0]["email"].ToString();
        lblUpd.Visible = false;

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text;
        Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(email);

        if (txtMobile.Text.Length > 0 && txtMobile.Text.Length != 10)
        {
            lblUpd.Visible = true;
            lblUpd.Text = "Mobile No. is not correct";
            lblUpd.ForeColor = System.Drawing.Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            lblUpd.Text = "";
            lblUpd.Focus();
            MultiView1.ActiveViewIndex = 1;
        }
        else if (txtPIN.Text.Length > 0 && txtPIN.Text.Length != 6)
        {
            lblUpd.Visible = true;
            lblUpd.Text = "PIN Code is not correct";
            lblUpd.ForeColor = System.Drawing.Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtPIN.Text = "";
            txtPIN.Focus();
            MultiView1.ActiveViewIndex = 1;
        }
        else if (!match.Success)
        {
            lblUpd.Visible = true;
            lblUpd.Text = "Email ID is not valid";
            lblUpd.ForeColor = System.Drawing.Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtEmail.Text = "";
            txtEmail.Focus();
            MultiView1.ActiveViewIndex = 1;
        }

        else
        {
            SAdapter.Update(Convert.ToInt32(Session["sid"].ToString()), txtname.Text, txtEmail.Text, txtMobile.Text, txtAddress.Text, txtCity.Text, txtPIN.Text);
            lblUpd.Visible = true;
            lblUpd.Text = "Data updated..";
            lblUpd.ForeColor = System.Drawing.Color.Blue;
            MultiView1.ActiveViewIndex = 1;
            txtname.Text = "";
            txtMobile.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtPIN.Text = "";
            txtEmail.Text = "";
        }
    }
    protected void Button14_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
    }
    protected void Button15_Click(object sender, EventArgs e)
    {
        SID = Session["sid"].ToString();
        try
        {
            SQLConn.Open();
            cmd = new SqlCommand("Select [password] from studentmst where [sid] = " + SID, SQLConn);
            cmd.Parameters.Add("@SID", SqlDbType.Int).Value = Session["sid"];
            dr = cmd.ExecuteReader();
            if (dr.HasRows == false)
            {
                throw new Exception();
            }
            if (dr.Read())
            {
                PrevPass = dr[0].ToString();
            }
        }
        catch (Exception ex)
        {
           
        }
        finally
        {
            SQLConn.Close();
        }

        if (txtCurrentPass.Text != "" && txtCnfPass.Text != "" && txtNewPass.Text != "")
        {
            if (txtNewPass.Text != txtCnfPass.Text)
            {
                lblPass.Visible = true;
                lblPass.ForeColor = System.Drawing.Color.Red;
                lblPass.Text = "New password and Confirm password is not same";
            }
            else if (txtCurrentPass.Text != PrevPass)
            {
                lblPass.Visible = true;
                lblPass.ForeColor = System.Drawing.Color.Red;
                lblPass.Text = "Current password is not matching";
            }
            else if (txtNewPass.Text == PrevPass || txtCnfPass.Text == PrevPass)
            {
                lblPass.Visible = true;
                lblPass.ForeColor = System.Drawing.Color.Red;
                lblPass.Text = "Current Password & New Password cannot be same.";
            }
            else if (txtCurrentPass.Text == PrevPass && txtCnfPass.Text == txtNewPass.Text && txtCnfPass.Text != PrevPass && txtNewPass.Text != PrevPass)
            {
                SqlCommand UpdateCommand = new SqlCommand("UPDATE studentmst SET [Password] ='" + txtCnfPass.Text + "' where [SID] = " + SID, SQLConn);
                SQLConn.Open();
                UpdateCommand.ExecuteNonQuery();
                SQLConn.Close();
                emailSend();
                lblPass.Visible = true;
                lblPass.ForeColor = System.Drawing.Color.Green;
                lblPass.Text = "Password Updated";
                txtCnfPass.Text = "";
                txtNewPass.Text = "";
                txtCurrentPass.Text = "";
            }
        }
        else if (txtCurrentPass.Text == "" || txtCnfPass.Text == "" || txtNewPass.Text == "")
        {
            lblPass.Visible = true;
            lblPass.ForeColor = System.Drawing.Color.Red;
            lblPass.Text = "Please provide all the information";
        }
        MultiView1.ActiveViewIndex = 2;
    }
    public void emailSend()
    {
        try
        {
            DataSet ds = new DataSet();
            DataSet dss = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Name, Email, Password FROM StudentMst Where [SID] = " + SID, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress("bcaproject.service@gmail.com");
                // Recipient e-mail address.
                Msg.To.Add(ds.Tables[0].Rows[0]["Email"].ToString());
                Msg.Subject = "LMS Password Changed";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["Name"] + ", <br/><br/>Recently you have changed your login credentials. Your Login credentials are given below:-. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + ds.Tables[0].Rows[0]["Email"] + "<b><br/><b>Your Password: <I>" + ds.Tables[0].Rows[0]["Password"] + "<I><b><br/><br/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }
}