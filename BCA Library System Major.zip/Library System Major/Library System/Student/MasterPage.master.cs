﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["sid"] == null)
        {
            Response.Redirect("../Default.aspx");
        }
        else
        {
            SDT = SAdapter.Select_By_SID(Convert.ToInt32(Session["sid"].ToString()));
            Image2.ImageUrl = SDT.Rows[0]["image"].ToString();
            lblname.Text = SDT.Rows[0]["studentname"].ToString();

            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from PenaltyMst where status = 0 and [SID] = " + Session["sid"].ToString(), SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                btnPenalty.Visible = false;
               // Response.Write("<script language='javascript'>window.alert('No Penalty entry is found, everything is as per schedule.');window.location='Home.aspx';</script>");
            }
            else if (count > 0)
            {
                btnPenalty.Visible = true;                
            }
        }
    }  
    protected void Button4_Click(object sender, EventArgs e)
    {
        Session["sid"] = null;
        Response.Redirect("../Default.aspx");
    }

    protected void btnPenalty_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Student/MyPenalty.aspx");
    }
}
