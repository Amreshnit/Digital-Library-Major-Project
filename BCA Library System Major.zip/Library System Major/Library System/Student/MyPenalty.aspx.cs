﻿using paytm;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_MyPenalty : System.Web.UI.Page
{
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");

    string email, mobile, sid, amount, callback, tid, currentdate, entrydate;
    SqlDataReader myReader = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["sid"] != null)
        {
            if (!IsPostBack)
            {
                SQLConn.Open();
                SqlCommand cmd = new SqlCommand("select COUNT(*) from PenaltyMst where [SID] = " + Session["sid"].ToString(), SQLConn);
                
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                SQLConn.Close();

                if (count == 0)
                {                    
                    Response.Write("<script language='javascript'>window.alert('No Penalty entry is found, everything is as per schedule.');window.location='../Student/Default.aspx';</script>");
                }
                else if (count > 0)
                {
                    BindPriceData();

                    (Page.Master.FindControl("btnPenaltyRpt") as Button).Enabled = false;
                    (Page.Master.FindControl("btnPenaltyRpt") as Button).BackColor = System.Drawing.Color.DarkOrange;
                }
                              
            }
        }
        else
        {
            Response.Redirect("~/Default.aspx");
        }
    }

    public void BindPriceData()
    {
        SQLConn.Open();
        SqlDataAdapter SQLAdapter = new SqlDataAdapter("select Tran_ID, bookname, panalty, convert(varchar(50), entrydate, 105) as entrydate, [status] from PenaltyMst where [SID] = " + Session["sid"].ToString(), SQLConn);
        DataTable DT = new DataTable();
        SQLAdapter.Fill(DT);

        GridView3.DataSource = DT;
        GridView3.DataBind();
        SQLConn.Close();

    }
    protected void GridView3_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Pay Now")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = GridView3.Rows[rowIndex];

            currentdate = DateTime.Now.ToString("dd-MM-yyyy");
            entrydate = row.Cells[3].Text;
            amount = row.Cells[2].Text;
            tid = row.Cells[0].Text; 

           // Random r = new Random();
            //int tranid = r.Next(10000, 99999);
           // tid = "T" + Convert.ToString(tranid);
            Session["orderid"] = tid;
            sid = Session["sid"].ToString();
            callback = "http://localhost:49912/Student/Callback.aspx";

            SQLConn.Open();
            SqlCommand myCommand = new SqlCommand("select email, mobile from studentmst where [sid] ='" + Session["sid"].ToString() + "'", SQLConn);
            myReader = myCommand.ExecuteReader();
            while (myReader.Read())
            {
                email = (myReader["email"].ToString());
                mobile = (myReader["mobile"].ToString());
            }
            SQLConn.Close();
            if (currentdate == entrydate)
            {
                PaytmPayment(email, mobile, sid, tid, amount, callback);

            }
            else if (currentdate != entrydate)
            {
                Response.Write("<script language='javascript'>window.alert('Penalty entry is not upto date. Contact LMS Admin.');window.location='../Student/Default.aspx';</script>");
            }
        }
    }
    public void PaytmPayment(string EMAIL, string MOBILE_NO, string CUST_ID, string ORDER_ID, string TXN_AMOUNT, string CALLBACK_URL)
    {
        String merchantKey = "gKpu7IKaLSbkchFS";
        Dictionary<string, string> parameters = new Dictionary<string, string>();
        parameters.Add("MID", "rxazcv89315285244163");
        parameters.Add("CHANNEL_ID", "WEB");
        parameters.Add("INDUSTRY_TYPE_ID", "Retail");
        parameters.Add("WEBSITE", "WEBSTAGING");
        parameters.Add("EMAIL", EMAIL);
        parameters.Add("MOBILE_NO", MOBILE_NO);
        parameters.Add("CUST_ID", CUST_ID);
        parameters.Add("ORDER_ID", ORDER_ID);
        parameters.Add("TXN_AMOUNT", TXN_AMOUNT);
        parameters.Add("CALLBACK_URL", CALLBACK_URL); //This parameter is not mandatory. Use this to pass the callback url dynamically.

        string checksum = CheckSum.generateCheckSum(merchantKey, parameters);

        string paytmURL = "https://securegw-stage.paytm.in/theia/processTransaction?orderid=" + ORDER_ID;

        string outputHTML = "<html>";
        outputHTML += "<head>";
        outputHTML += "<title>Merchant Check Out Page</title>";
        outputHTML += "</head>";
        outputHTML += "<body>";
        outputHTML += "<center><h1>Please do not refresh this page...</h1></center>";
        outputHTML += "<form method='post' action='" + paytmURL + "' name='f1'>";
        outputHTML += "<table border='1'>";
        outputHTML += "<tbody>";
        foreach (string key in parameters.Keys)
        {
            outputHTML += "<input type='hidden' name='" + key + "' value='" + parameters[key] + "'>";
        }
        outputHTML += "<input type='hidden' name='CHECKSUMHASH' value='" + checksum + "'>";
        outputHTML += "</tbody>";
        outputHTML += "</table>";
        outputHTML += "<script type='text/javascript'>";
        outputHTML += "document.f1.submit();";
        outputHTML += "</script>";
        outputHTML += "</form>";
        outputHTML += "</body>";
        outputHTML += "</html>";
        Response.Write(outputHTML);
    }

    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button btn = (e.Row.FindControl("lnkPay") as Button);
            if (e.Row.Cells[4].Text == "1")
            {
                btn.Enabled = false;
                btn.Text = "Paid";
            }
            else
            {
                btn.Enabled = true;
                btn.Text = "Pay Now";
            }
        }
    }
}

  