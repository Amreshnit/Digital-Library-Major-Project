﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using paytm;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;

public partial class Callback : System.Web.UI.Page
{
    SqlCommand command;
    SqlDataAdapter adapter = new SqlDataAdapter();
    String sql = "";
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        String merchantKey = "gKpu7IKaLSbkchFS"; // Replace the with the Merchant Key provided by Paytm at the time of registration.

        Dictionary<string, string> parameters = new Dictionary<string, string>();
        string paytmChecksum = "";
        foreach (string key in Request.Form.Keys)
        {
            parameters.Add(key.Trim(), Request.Form[key].Trim());
        }

        if (parameters.ContainsKey("CHECKSUMHASH"))
        {
            paytmChecksum = parameters["CHECKSUMHASH"];
            parameters.Remove("CHECKSUMHASH");
        }

        if (CheckSum.verifyCheckSum(merchantKey, parameters, paytmChecksum))
        {
            string paytmStatus = parameters["STATUS"];
            string txnId = parameters["TXNID"];
            pTxnId.InnerText = "Transaction Id : " + txnId;
         
            if (paytmStatus == "TXN_SUCCESS")
            {
                h1Message.InnerText = "Your payment is success";
                //lbl.Text = "Your payment is success";
                SQLConn.Open();
                sql = "update PenaltyMst set status = 1 where Tran_ID = '" + Session["orderid"].ToString()+"'";
                command = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand.ExecuteNonQuery();
            }
            else if (paytmStatus == "PENDING")
            {
                h1Message.InnerText = "Payment is pending !";

               // lbl.Text = "Payment is pending !";
            }
            else if (paytmStatus == "TXN_FAILURE")
            {
                h1Message.InnerText = "Payment Failure !";

               // lbl.Text = "Payment Failure !";
            }
            SQLConn.Close();
        }
        else
        {
            Response.Write("Checksum MisMatch");
        }

        HtmlMeta meta = new HtmlMeta();
        meta.HttpEquiv = "Refresh";
        meta.Content = "5;url=../Student/Default.aspx";
        this.Page.Controls.Add(meta);
        lbl.Text = "You will now be redirected in 5 seconds";
    }
}