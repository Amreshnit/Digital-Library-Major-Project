﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PassChng : System.Web.UI.Page
{
    System.Data.SqlClient.SqlCommand cmd = new SqlCommand();
    System.Data.SqlClient.SqlDataReader dr;
    DataSet ds;
    System.Data.SqlClient.SqlDataAdapter da;
    string AID, PrevPass;
    System.Data.SqlClient.SqlConnection SQLConn = new System.Data.SqlClient.SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        AID = Session["aid"].ToString();
        try
        {
            SQLConn.Open();
            cmd = new SqlCommand("Select [password] from adminmst where aid = " + AID, SQLConn);
            cmd.Parameters.Add("@AID", SqlDbType.Int).Value = Session["aid"];
            dr = cmd.ExecuteReader();
            if (dr.HasRows == false)
            {
                throw new Exception();
            }
            if (dr.Read())
            {
                PrevPass = dr[0].ToString();
            }
        }
        catch (Exception ex)
        {
            lbl.Visible = true;
            lbl.ForeColor = System.Drawing.Color.Red;
            lbl.Text = ex.Message;
        }
        finally
        {
            SQLConn.Close();
        }
    }  

    protected void btnclose_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.close()</script>");
    }
    public void emailSend()
    {
        try
        {
            DataSet ds = new DataSet();
            DataSet dss = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Name, Email, Password FROM AdminMst Where Email= '" + Session["aid"].ToString() + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress("bcaproject.service@gmail.com");
                // Recipient e-mail address.
                Msg.To.Add(ds.Tables[0].Rows[0]["Email"].ToString());
                Msg.Subject = "LMS Password Changed";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["Name"] + ", <br/><br/>Recently you have changed your login credentials. Your Login credentials are given below:-. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + ds.Tables[0].Rows[0]["Email"] + "<b><br/><b>Your Password: <I>" + ds.Tables[0].Rows[0]["Password"] + "<I><b><br/><br/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);               
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);                             
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
     if (txtPrvPass.Text != "" && txtCnfPass.Text != "" && txtNewPass.Text != "")
        {
            if (txtNewPass.Text != txtCnfPass.Text)
            {
                lbl.Visible = true;
                lbl.ForeColor = System.Drawing.Color.Red;
                lbl.Text = "New password and Confirm password is not same";
            }
            else if (txtPrvPass.Text != PrevPass)
            {
                lbl.Visible = true;
                lbl.ForeColor = System.Drawing.Color.Red;
                lbl.Text = "Current password is not matching";
            }
            else if (txtNewPass.Text == PrevPass || txtCnfPass.Text == PrevPass)
            {
                lbl.Visible = true;
                lbl.ForeColor = System.Drawing.Color.Red;
                lbl.Text = "Current Password & New Password cannot be same.";
            }
            else if (txtPrvPass.Text == PrevPass && txtCnfPass.Text == txtNewPass.Text && txtCnfPass.Text != PrevPass && txtNewPass.Text != PrevPass)
            {
                SqlCommand UpdateCommand = new SqlCommand("UPDATE AdminMst SET [Password] ='" + txtCnfPass.Text + "' where AID = " + AID, SQLConn);
                SQLConn.Open();
                UpdateCommand.ExecuteNonQuery();
                SQLConn.Close();
                emailSend();
                lbl.Visible = true;
                lbl.ForeColor = System.Drawing.Color.Green;
                lbl.Text = "Password Updated";
                txtCnfPass.Text = "";
                txtNewPass.Text = "";
                txtPrvPass.Text = "";
                btnclose.Focus();

            }
        }
     else if (txtPrvPass.Text == "" || txtCnfPass.Text == "" || txtNewPass.Text == "")
        {
            lbl.Visible = true;
            lbl.Text = "Please provide all the information";
        }
    }
}