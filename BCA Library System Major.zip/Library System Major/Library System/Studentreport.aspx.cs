﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Studenteport : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();

    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from StudentMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Student found, First add Student.');window.location='AddStudent.aspx';</script>");
            }
            else if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                drpbranch.DataSource = BDT;
                drpbranch.DataTextField = "Branchname";
                drpbranch.DataValueField = "Branchid";
                drpbranch.DataBind();
                drpbranch.Items.Insert(0, "SELECT");
                MultiView1.ActiveViewIndex = -1;
                (Page.Master.FindControl("btnSTudentRpt") as Button).Enabled = false;
                (Page.Master.FindControl("btnSTudentRpt") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }
        }
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        if (drpbranch.SelectedIndex == 0)
        {
            lblmsg.Text = "Select Branch first";
            MultiView1.ActiveViewIndex = -1;
        }
        else
        {
            this.SDT.Reset();
            SDT = SAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
            GridView1.DataSource = SDT;
            GridView1.DataBind();
            MultiView1.ActiveViewIndex = 0;
            lbl.Text = GridView1.Rows.Count.ToString() + " Student Found";
            txtsearch.Text = "";
        }
    }
    protected void btnseach_Click(object sender, EventArgs e)
    {
        if (txtsearch.Text == "")
        {
            lblmsg.Text = "Enter student name";
        }
        else
        {
            this.SDT.Reset();
            SDT = SAdapter.Select_For_SEARCH(txtsearch.Text + "%");
            GridView1.DataSource = SDT;
            GridView1.DataBind();
            MultiView1.ActiveViewIndex = 0;
            lbl.Text = GridView1.Rows.Count.ToString() + " Student Found";
            drpbranch.SelectedIndex = 0;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
        SDT = SAdapter.Select_By_SID(Convert.ToInt32(e.CommandArgument.ToString()));
        Session["STDID"] = SDT.Rows[0]["sid"].ToString();
        lblname.Text = SDT.Rows[0]["studentname"].ToString();
        Session["StudentName"] = SDT.Rows[0]["studentname"].ToString();
        lblbranch.Text = SDT.Rows[0]["branchname"].ToString();
        lblmobile.Text = SDT.Rows[0]["mobile"].ToString();
        lbladdress.Text = SDT.Rows[0]["address"].ToString();
        lblcity.Text = SDT.Rows[0]["city"].ToString();
        lblpin.Text = SDT.Rows[0]["pincode"].ToString();
        DateTime dobb = Convert.ToDateTime(SDT.Rows[0]["dob"].ToString());
        lbldob.Text = dobb.GetDateTimeFormats()[7].ToString();
        lblemai.Text = SDT.Rows[0]["email"].ToString();

        SQLConn.Open();
        SqlCommand cmd = new SqlCommand("select COUNT(sid) from RentMst where SID = " + Session["STDID"].ToString() + "and Status = 0", SQLConn);
        int count = Convert.ToInt32(cmd.ExecuteScalar());

        if (count == 0)
        {
            btndlt.Enabled = true;
            lblstatus.Visible = false;
        }
        else if (count > 0)
        {
            btndlt.Enabled = false;
            lblstatus.Text = "This student cannot be deleted, because all book/s are not yet returned.";
            lblstatus.Visible = true;
            lblstatus.ForeColor = System.Drawing.Color.Red;
        }
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }

    protected void btndlt_Click(object sender, EventArgs e)
    {
        if (btndlt.Enabled == true)
        {
            string qry = "DELETE FROM studentmst where SID = " + Session["STDID"].ToString();
            SQLConn.Open();
            SqlCommand com = new SqlCommand(qry, SQLConn);
            com.ExecuteNonQuery();
            SQLConn.Close();

            if (txtsearch.Text != "")
            {
                SDT = SAdapter.Select_For_SEARCH(txtsearch.Text + "%");
                GridView1.DataSource = SDT;
                GridView1.DataBind();
                MultiView1.ActiveViewIndex = 0;
            }
            else if (drpbranch.SelectedIndex > 0)
            {
                SDT = SAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
                GridView1.DataSource = SDT;
                GridView1.DataBind();
                MultiView1.ActiveViewIndex = 0;
            }
            lblmsg.Text = "'" + Session["StudentName"].ToString() + "' has been deleted";
            Session["StudentName"] = null;

        }
    }

}