﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Panalty : System.Web.UI.Page
{
   
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    

    protected void Page_Load(object sender, EventArgs e)
    {             
        if (Page.IsPostBack == false)
        {
            MultiView1.ActiveViewIndex = -1;
            lblmsg.Visible = false;

            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from PenaltyMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Penalty entry is found, everything is as per schedule.');window.location='Home.aspx';</script>");
            }
            else if (count > 0)
            {
                SqlCommand com = new SqlCommand("select distinct branchname from StudentMst where [sid] in (select distinct [sid] from [PenaltyMst])", SQLConn); // table name 
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataSet ds = new DataSet();
                da.Fill(ds);  // fill dataset
                drpbranch.DataTextField = ds.Tables[0].Columns["branchname"].ToString(); // text field name of table dispalyed in dropdown
                drpbranch.DataValueField = ds.Tables[0].Columns["branchname"].ToString();             // to retrive specific  textfield name 
                drpbranch.DataSource = ds.Tables[0];      //assigning datasource to the dropdownlist
                drpbranch.DataBind();  //binding dropdownlist
                drpbranch.Items.Insert(0, "-- Select Branch --");
                drpbranch.SelectedIndex = 0;

                (Page.Master.FindControl("btnFine") as Button).Enabled = false;
                (Page.Master.FindControl("btnFine") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }        
        }
    }

    protected void btnbrnch_Click(object sender, EventArgs e)
    {
        if (drpbranch.SelectedIndex == 0)
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Please select the branch";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            MultiView1.ActiveViewIndex = -1;
        }
        else
        {
            lblmsg.Visible = false;
            using (SqlCommand cmd = new SqlCommand("select p.tran_id, s.studentname, p.bookname, p.panalty, p.[status], CONVERT(VARCHAR(10), p.EntryDate, 103) as [entrydate] from [PenaltyMst] p join studentmst s on p.[sid] = s.[sid] where s.branchname = '" + drpbranch.SelectedValue + "'", SQLConn))
            {               
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    cmd.Connection = SQLConn;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        MultiView1.ActiveViewIndex = 0;
                        lbl.Text = GridView1.Rows.Count.ToString() + " Record Found";                       
                       
                    }
                }
            }
        }
    }
    protected void btnName_Click(object sender, EventArgs e)
    {
        if (txtstdName.Text  == "")
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Please provide student name";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            MultiView1.ActiveViewIndex = -1;
            drpbranch.SelectedIndex = 0;
        }
        else
        {
            lblmsg.Visible = false;

            using (SqlCommand cmd = new SqlCommand("select p.tran_id, s.studentname, p.bookname, p.panalty, p.[status], CONVERT(VARCHAR(10), p.EntryDate, 103) as [entrydate] from [PenaltyMst] p join studentmst s on p.[sid] = s.[sid] where s.StudentName LIKE  '%" + txtstdName.Text+"%'  ", SQLConn))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    cmd.Connection = SQLConn;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        MultiView1.ActiveViewIndex = 0;
                        lbl.Text = GridView1.Rows.Count.ToString() + " Record Found";
                        txtstdName.Text = "";
                        drpbranch.SelectedIndex = 0;
                       
                    }
                }
            }
        }
    }
}