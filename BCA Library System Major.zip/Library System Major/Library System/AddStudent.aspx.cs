﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddStudent : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();

    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    string password;
    int count;
    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from BranchMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                drpbranch.DataSource = BDT;
                drpbranch.DataTextField = "Branchname";
                drpbranch.DataValueField = "Branchid";
                drpbranch.DataBind();
                drpbranch.Items.Insert(0, "-- SELECT BRANCH --");
                rdomale.Checked = false;
                rdofemale.Checked = false;
                (Page.Master.FindControl("btnStudent") as Button).Enabled = false;
                (Page.Master.FindControl("btnStudent") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }
            else if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Branch found, First add Branch.');window.location='Addbranch.aspx';</script>");
            }
        }
    }
    private static string CreateRandomPassword(int length = 10)
    {
        // Create a string of characters, numbers, special characters that allowed in the password  
        string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*-_";
        Random random = new Random();

        // Select one random character at a time from the string  
        // and create an array of chars  
        char[] chars = new char[length];
        for (int i = 0; i < length; i++)
        {
            chars[i] = validChars[random.Next(0, validChars.Length)];
        }
        return new string(chars);

    }
    public void emailSend()
    {
        try
        {
            DataSet ds = new DataSet();
            DataSet dss = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT SID, StudentName, BranchName, Email, Password FROM StudentMst Where Email= '" + txtemail.Text.Trim() + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress(txtemail.Text);
                // Recipient e-mail address.
                Msg.To.Add(txtemail.Text);
                Msg.Subject = "LMS Student Details";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["StudentName"] + ", <br/><br/>Your LMS student account has been created. Your Login credentials are given below:-. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + ds.Tables[0].Rows[0]["Email"] + "<b/><br/><b>Your Password: <I>" + ds.Tables[0].Rows[0]["Password"] + "<I/><b/><br/><b> Your Branch: <I> " + ds.Tables[0].Rows[0]["BranchName"] + " <I/><b/><br/><br/><b>Regards, <br/>LMS Admin<B/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);             
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }

    public void SMS()
    {
        try
        {
            string destination = "91" + txtmobile.Text.Trim();
            string message = "Welcome " + txtsname.Text.Trim() + ", Your UserID is - " + txtemail.Text.Trim() + " And Your Password is " + password + "(Regards - LMS)";
            String message1 = HttpUtility.UrlEncode(message);
           

            //Send message
            using (var wb = new System.Net.WebClient())
            {
                byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "g2GFKqrniF4-jLt5tSvpDpSS0GOOl24IAKHO3tsHD0"},
                {"numbers" , destination},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
                string result = System.Text.Encoding.UTF8.GetString(response);
                
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message.ToString();
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
       if (txtmobile.Text.Length > 0 && txtmobile.Text.Length != 10)
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Mobile No. is not correct";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtmobile.Text = "";
            txtmobile.Focus();
        }
       else if (txtpincode.Text.Length > 0 && txtpincode.Text.Length != 6)
        {
            lblmsg.Visible = true;
            lblmsg.Text = "PIN Code is not correct";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtpincode.Text = "";
            txtpincode.Focus();
        }
       else
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(Email) from studentmst where Email = '" + txtemail.Text + "'", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                if (drpdd.SelectedIndex == 0 || drpmm.SelectedIndex == 0 || drpyyyy.SelectedIndex == 0)
                {
                    lblmsg.Text = "Select Proper BithDate";
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                }
                else if (drpbranch.SelectedIndex == 0)
                {
                    lblmsg.Text = "Select Proper Branch";
                    lblmsg.Visible = true;
                    drpbranch.Focus();
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                }
                else if (rdomale.Checked == false && rdofemale.Checked == false)
                {
                    lblmsg.Text = "Select the Gender";
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                }
                else
                {
                    password = CreateRandomPassword().ToString();
                    string gen = "";
                    if (rdomale.Checked == true)
                    {
                        gen = "Male";
                    }
                    else
                    {
                        gen = "Female";
                    }
                    if (FileUpload1.HasFile)
                    {
                        FileUpload1.SaveAs(Server.MapPath("~/img/") + FileUpload1.FileName);
                        DateTime bdate = Convert.ToDateTime(drpdd.SelectedItem.Text + " " + drpmm.SelectedItem.Text + " " + drpyyyy.SelectedItem.Text);
                        SAdapter.Insert(txtsname.Text, drpbranch.SelectedItem.Text, txtmobile.Text, txtaddress.Text, txtcity.Text, txtpincode.Text, bdate, gen, txtemail.Text, password, "~/img/" + FileUpload1.FileName);
                        SMS();
                        emailSend();

                        lblmsg.Visible = true;
                        lblmsg.Text = "Student Added Successfully and Login credentials sent to Student Email ID and Mobile.";
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                        clean();

                    }
                    else
                    {
                        DateTime bdate = Convert.ToDateTime(drpdd.SelectedItem.Text + " " + drpmm.SelectedItem.Text + " " + drpyyyy.SelectedItem.Text);
                        SAdapter.Insert(txtsname.Text, drpbranch.SelectedItem.Text, txtmobile.Text, txtaddress.Text, txtcity.Text, txtpincode.Text, bdate, gen, txtemail.Text, password, "~/img/std.png");
                        SMS();
                        emailSend();

                        lblmsg.Visible = true;
                        lblmsg.Text = "Student Added Successfully and Login credentials sent to Student Email ID and Mobile.";
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                        clean();
                    }
                }
            }

            else if (count > 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "This Email ID is already in use.";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                
                txtemail.Text = "";
                txtemail.Focus();
            }
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        clean();
    }
    public void clean()
    {
        txtaddress.Text = "";
        txtcity.Text = "";
        txtemail.Text = "";
        txtmobile.Text = "";
        txtpincode.Text = "";
        txtsname.Text = "";
        drpdd.SelectedIndex = 0;
        drpmm.SelectedIndex = 0;
        drpyyyy.SelectedIndex = 0;
        drpbranch.SelectedIndex = 0;
        rdofemale.Checked = false;
        rdomale.Checked = false;       
    }
}