﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Addbranch : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();
    DS_BOOK.BOOK_SELECTDataTable BookDT = new DS_BOOK.BOOK_SELECTDataTable();
    DS_BOOKTableAdapters.BOOK_SELECTTableAdapter BookAdapter = new DS_BOOKTableAdapters.BOOK_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from BranchMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            SQLConn.Close();
            if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                GridView1.DataSource = BDT;
                GridView1.DataBind();
            }
            txtaddbranch.Focus();
            (Page.Master.FindControl("btnBranch") as Button).Enabled = false;
            (Page.Master.FindControl("btnBranch") as Button).BackColor = System.Drawing.Color.DarkOrange;
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        SQLConn.Open();
        SqlCommand cmd = new SqlCommand("select COUNT(*) from BranchMst where branchname = '"+txtaddbranch.Text+"'", SQLConn);
        int count = Convert.ToInt32(cmd.ExecuteScalar());
        SQLConn.Close();
        if (count == 0)
        {
            BAdapter.Insert(txtaddbranch.Text);
            lblmsg.Text = "Branch Saved";            
        }
        else if (count > 0)
        {
            lblmsg.Text = "This Branch is already added";
            lblmsg.ForeColor = System.Drawing.Color.Red;           
        }
        BDT = BAdapter.SelectBranch();
        GridView1.DataSource = BDT;
        GridView1.DataBind();
        txtaddbranch.Text = "";
        txtaddbranch.Focus();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int bid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        BDT = BAdapter.Select_By_BID(bid);

        SDT = SAdapter.Select_By_Branch(BDT.Rows[0]["branchname"].ToString());
        BookDT = BookAdapter.Select_By_Branch(BDT.Rows[0]["branchname"].ToString());
       
        if (SDT.Rows.Count > 0 || BookDT.Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>window.alert('Branch cannot be deleted, as it has Books under it.');window.location='Addbranch.aspx';</script>");
        }
        else
        {
            BAdapter.Delete(bid);
            lblmsg.Text = "Branch Deleted";
            BDT = BAdapter.SelectBranch();
            GridView1.DataSource = BDT;
            GridView1.DataBind();
        }
        
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BDT = BAdapter.SelectBranch();
        GridView1.DataSource = BDT;
        GridView1.DataBind();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        BDT = BAdapter.SelectBranch();
        GridView1.DataSource = BDT;
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int bid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        TextBox bname = GridView1.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox;

        BAdapter.Update(bid, bname.Text);
        lblmsg.Text = "Branch Updated";
        GridView1.EditIndex = -1;
        BDT = BAdapter.SelectBranch();
        GridView1.DataSource = BDT;
        GridView1.DataBind();

    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
        TableHeaderCell cell = new TableHeaderCell();
        cell.Text = "Branch Name";
        cell.ColumnSpan = 3;
        cell.HorizontalAlign = HorizontalAlign.Center;
        cell.VerticalAlign = VerticalAlign.Middle;
        row.Controls.Add(cell);
        row.BackColor = System.Drawing.ColorTranslator.FromHtml("#000066");
        row.ForeColor = System.Drawing.ColorTranslator.FromHtml("Aqua");
        GridView1.HeaderRow.Parent.Controls.AddAt(0, row);
    }
}