﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Specialized;

public partial class Forgot : System.Web.UI.Page
{
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    string password;
    int count, UniversalCount, AID, FRID, rowIndex;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from adminmst", SQLConn);
            UniversalCount = Convert.ToInt32(cmd.ExecuteScalar());
            if (UniversalCount > 0)
            {
                BindGrid();
                lbl.Visible = false;
                btnsave.Enabled = false;           
            }
        
        }
    }
    private void BindGrid()
    {
        SqlDataAdapter SQLAdapter = new SqlDataAdapter("Select AID, Name, Email from AdminMst", SQLConn);
        DataTable DT = new DataTable();
        SQLAdapter.Fill(DT);

        GridView1.DataSource = DT;
        GridView1.DataBind();
    }
    private static string CreateRandomPassword(int length = 10)
    {
        // Create a string of characters, numbers, special characters that allowed in the password  
        string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*-_";
        Random random = new Random();

        // Select one random character at a time from the string  
        // and create an array of chars  
        char[] chars = new char[length];
        for (int i = 0; i < length; i++)
        {
            chars[i] = validChars[random.Next(0, validChars.Length)];
        }
        return new string(chars);
        
    }
   protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindGrid();
        
        //Set the TextBox as ReadOnly.
        (GridView1.Rows[e.NewEditIndex].Cells[3].Controls[0] as TextBox).ReadOnly = true;

        //Set the TextBox as Disabled.
        (GridView1.Rows[e.NewEditIndex].Cells[3].Controls[0] as TextBox).Enabled = false;

        GenOTPMod();
        Response.Write("<script language='javascript'>window.alert('Modification OTP sent, use it within 5 mins');</script>");
        Hide();
        btnverify.Visible = false;

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        BindGrid();
        show();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int AID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);

        TextBox tname = GridView1.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox;     

        if (Session["OTPMod"].ToString() == txtOTP.Text && txtOTP.Text != "")
        {
            SqlDataAdapter SQLAdapter = new SqlDataAdapter("update AdminMst set name='" + tname.Text + "' where AID = " + AID + "", SQLConn);
            DataTable DT = new DataTable();
            SQLAdapter.Fill(DT);

            GridView1.EditIndex = -1;
            BindGrid();
            lbl.Visible = true;
            lbl.Text = "User Details Updated";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            show();
            txtOTP.Text = "";
        }
        else if (Session["OTPMod"].ToString() != txtOTP.Text && txtOTP.Text != "")
        {
            lblMod.Visible = true;
            lblMod.Text = "Please enter correct OTP.";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
           txtOTP.Text = "";
            txtOTP.Focus();
            BindGrid();
            Hide();
            GridView1.Rows[e.RowIndex].Cells[3].Enabled = false; ;
        }
        else if (txtOTP.Text == "")
        {
            lblMod.Visible = true;
            lblMod.Text = "OTP cannot be left blank";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtOTP.Text = "";
            txtOTP.Focus();
            BindGrid();
            Hide();
            GridView1.Rows[e.RowIndex].Cells[3].Enabled = false; ;
        }

    }
    public void Hide()
    {
        lblemail.Visible = false;
        lblname.Visible = false;
        btnclose.Visible = false;
        btnsave.Visible = false;
        btnOTPGen.Visible = false;
        txtemail.Visible = false;
        txtname.Visible = false;
    }
    public void show()
    {
        lblemail.Visible = true;
        lblname.Visible = true;
        btnclose.Visible = true;
        btnsave.Visible = true;
        btnOTPGen.Visible = true;
        txtemail.Visible = true;
        txtname.Visible = true;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int AID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        rowIndex = e.RowIndex;
        Session["AID"] = null;
        Session["AID"] = AID;
        Session["RID"] = rowIndex;
        GenOTPMod();
        Response.Write("<script language='javascript'>window.alert('Modification OTP sent, use it within 5 mins');</script>");
        Hide();
        btnverify.Visible = true;
        BindGrid();
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        //if (UniversalCount > 0)
       // {
            GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
            TableHeaderCell cell = new TableHeaderCell();
            cell.Text = "User Details";
            cell.ColumnSpan = 3;
            cell.HorizontalAlign = HorizontalAlign.Center;
            cell.VerticalAlign = VerticalAlign.Middle;
            row.Controls.Add(cell);

            row.BackColor = System.Drawing.ColorTranslator.FromHtml("#000066");
            row.ForeColor = System.Drawing.ColorTranslator.FromHtml("Aqua");
           GridView1.HeaderRow.Parent.Controls.AddAt(0, row);
       // }
    }
    public void emailSend()
    {
        try
        {
            DataSet ds = new DataSet();
            DataSet dss = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT AID, Name, Email, Password FROM AdminMst Where Email= '" + txtemail.Text.Trim() + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);                
                da.Fill(ds);               
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress(txtemail.Text);
                // Recipient e-mail address.
                Msg.To.Add(txtemail.Text);
                Msg.Subject = "LMS User Details";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["Name"] + ", <br/><br/>Your LMS account has been created. Your Login credentials are given below:-. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + ds.Tables[0].Rows[0]["Email"] + "<b><br/><b>Your Password: <I>" + ds.Tables[0].Rows[0]["Password"] + "<I><b><br/><br/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                lbl.Visible = true;
                lbl.Text = "Login details sent to Email";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                // Clear the textbox valuess
                // txtfrgt.Text = "";    
                clean();
            }         
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }
    public void clean()
    {
        txtemail.Text = "";
        txtname.Text = "";
        lbl.Visible = false;
        BindGrid();
        txtOTP.Text = "";
    }
    protected void btnclose_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.close()</script>");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[1].Visible = false;      
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        SQLConn.Open();
        SqlCommand cmd = new SqlCommand("select COUNT(Email) from adminmst where Email = '" + txtemail.Text + "'", SQLConn);
        int count = Convert.ToInt32(cmd.ExecuteScalar());

        if (count == 0)
        {
            if (Session["OTP"].ToString() == txtOTP.Text && btnsave.Enabled == true)
            {
                password = CreateRandomPassword().ToString();
                SqlDataAdapter SQLAdapter = new SqlDataAdapter("insert into AdminMst ([Name], Email, [Password], EntryDate) values ('" + txtname.Text + "','" + txtemail.Text + "','" + password + "', GetDate())", SQLConn);
                DataTable DT = new DataTable();
                SQLAdapter.Fill(DT);
                BindGrid();
                lbl.Text = "User Added";
                lbl.Visible = true;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                emailSend();
                Session["OTP"] = null;
                btnsave.Enabled = false;
            }
            else if (Session["OTP"].ToString() != txtOTP.Text)
            {
                lbl.Visible = true;
                lbl.Text = "Please enter correct OTP.";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                txtOTP.Text = "";
                txtOTP.Focus();
                BindGrid();
            }
            else if (Session["OTP"].ToString() == null && btnsave.Enabled == false)
            {
                lbl.Visible = true;
                lbl.Text = "Please Generate OTP at first.";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                txtOTP.Text = "";
                btnOTPGen.Focus();
                BindGrid();
            }

        }
        else if (count > 0)
        {
            string message = "This Email ID is already in use.";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("');");
            ClientScript.RegisterOnSubmitStatement(this.GetType(), "alert", sb.ToString());
            txtemail.Text = "";
            txtemail.Focus();
            BindGrid();
        }
    }
    public void GenOTP()
    {
        try
        {
            //For generating OTP
            Random r = new Random();
            int OTP = r.Next(10000, 99999);

            string destination = "91" + "9122501795";
            string message = "User Registration OTP Number is " + OTP + " Use OTP within 5 mins (Regards - LMS)";
            String message1 = HttpUtility.UrlEncode(message);


            Session["OTP"] = OTP;

            //Send message
            using (var wb = new System.Net.WebClient())
            {
                byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "g2GFKqrniF4-jLt5tSvpDpSS0GOOl24IAKHO3tsHD0"},
                {"numbers" , destination},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
                string result = System.Text.Encoding.UTF8.GetString(response);
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message.ToString();
        }
    }
    public void GenOTPMod()
    {
        try
        {
            //For generating OTP
            Random r = new Random();
            int OTP = r.Next(10000, 99999);

            string destination = "91" + "9122501795";
            string message = "User MOdification OTP Number is " + OTP + " Use OTP within 5 mins (Regards - LMS)";
            String message1 = HttpUtility.UrlEncode(message);


            Session["OTPMod"] = OTP;

            //Send message
            using (var wb = new System.Net.WebClient())
            {
                byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "g2GFKqrniF4-jLt5tSvpDpSS0GOOl24IAKHO3tsHD0"},
                {"numbers" , destination},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
                string result = System.Text.Encoding.UTF8.GetString(response);
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message.ToString();
        }
    }
    protected void btnOTPGen_Click(object sender, EventArgs e)
    {
        GenOTP();
        BindGrid();
        btnsave.Enabled = true;
    }
    protected void btnverify_Click(object sender, EventArgs e)
    {

        if (Session["OTPMod"].ToString() == txtOTP.Text && txtOTP.Text != "")
        {
            int delParm = Convert.ToInt32(Session["AID"].ToString());
            SqlDataAdapter SQLAdapter = new SqlDataAdapter("delete from AdminMst where AID = " + delParm, SQLConn);
            DataTable DT = new DataTable();
            SQLAdapter.Fill(DT);
            BindGrid();
            lbl.Visible = true;
            lbl.Text = "User Deleted";
            btnverify.Visible = false;
            Session["OTPMod"] = null;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtOTP.Text = "";
            show();
      
        }
        else if (Session["OTPMod"].ToString() != txtOTP.Text && txtOTP.Text != "")
        {
            lblMod.Visible = true;
            lblMod.Text = "Please enter correct OTP.";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtOTP.Text = "";
            txtOTP.Focus();
            BindGrid();
            Hide();
         //   GridView1.Rows[Convert.ToInt32(Session["RID"].ToString())].Cells[3].Enabled = false; ;
        }
        else if (txtOTP.Text == "" && Session["OTPMod"].ToString() != null)
        {
            lblMod.Visible = true;
            lblMod.Text = "OTP cannot be blank";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            txtOTP.Text = "";
            txtOTP.Focus();
            BindGrid();
            Hide();
          //  GridView1.Rows[Convert.ToInt32(Session["RID"].ToString())].Cells[3].Enabled = false; ;
        }
        Session["AID"] = null;
        Session["RID"] = null;

    }
}



