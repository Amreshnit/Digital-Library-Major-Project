﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Issuereport : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_RENT.RENT_SELECTDataTable RDT = new DS_RENT.RENT_SELECTDataTable();
    DS_RENTTableAdapters.RENT_SELECTTableAdapter RAdapter = new DS_RENTTableAdapters.RENT_SELECTTableAdapter();

    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        // lblmsg.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from RentMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Book has been issued to any Student, First issue some Books to Students.');window.location='BookIssue.aspx';</script>");
            }
            else if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                drpbranch.DataSource = BDT;
                drpbranch.DataTextField = "Branchname";
                drpbranch.DataValueField = "Branchid";
                drpbranch.DataBind();
                drpbranch.Items.Insert(0, "-- Select Branch --");
                //   
                // MultiView1.ActiveViewIndex = -1;
                (Page.Master.FindControl("btnIssueReport") as Button).Enabled = false;
                (Page.Master.FindControl("btnIssueReport") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }
        }

    }
    protected void drpbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpbranch.SelectedIndex > 0)
        {
            this.SDT.Reset();
            SDT = SAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
            drpstudent.DataSource = SDT;
            drpstudent.DataTextField = "Studentname";
            drpstudent.DataValueField = "sid";
            drpstudent.DataBind();    
            if (drpstudent.SelectedIndex == -1)
            {
                drpstudent.Items.Insert(0, "No Student Found");
                lblmsg.Visible = false;
            }
            else if (drpstudent.SelectedIndex > -1)
            {
                drpstudent.Items.Insert(0, "-- Select Student --");
                drpstudent.SelectedIndex = 0;
                lblmsg.Visible = false;
            }
        }
    }
   
    protected void btnseach_Click(object sender, EventArgs e)
    {
        if (drpstudent.SelectedIndex > 0)
        {
            lblmsg.Visible = false;
            this.RDT.Reset();
            RDT = RAdapter.Select_by_Status_and_SID(Convert.ToInt32(drpstudent.SelectedValue), 0);
            GridView1.DataSource = RDT;
            GridView1.DataBind();

            if (GridView1 == null || GridView1.Rows.Count == 0)
            {
                lblmsg.Text = "No record found";
                lblmsg.Visible = true;
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
           
    }
}