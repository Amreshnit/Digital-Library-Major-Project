﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.Net;

public partial class _Default : System.Web.UI.Page
{
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();
    DS_ADMIN.ADMIN_SELECTDataTable ADT = new DS_ADMIN.ADMIN_SELECTDataTable();
    DS_ADMINTableAdapters.ADMIN_SELECTTableAdapter AAdapter = new DS_ADMINTableAdapters.ADMIN_SELECTTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        lbl.Text = "";
        lblEmail.Visible = false;
        txtfrgt.Visible = false;


    }
    public void clean()
    {
        txtuname.Text = "";
        txtupass.Text = "";
        rdolibrary.Checked = false;
        rdosudent.Checked = false;
        txtuname.Focus();
        lblEmail.Visible = false;
        txtfrgt.Visible = false;
        txtfrgt.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (rdolibrary.Checked == false && rdosudent.Checked == false)
        {
            lbl.Text = "Select the Login Type";

        }
        else if (rdolibrary.Checked == true)
        {
            ADT = AAdapter.Select_for_LOGIN(txtuname.Text, txtupass.Text);
            if (ADT.Rows.Count > 0)
            {
                Session["aid"] = ADT.Rows[0]["aid"].ToString();
                Session["email"] = txtuname.Text;
                Session["name"] = ADT.Rows[0]["name"].ToString();
                Response.Redirect("Home.aspx");

            }
            else
            {
                lbl.Text = "Invalid Credential";
                clean();
            }
        }
        else if (rdosudent.Checked == true)
        {
            SDT = SAdapter.Select_for_LOGIN(txtuname.Text, txtupass.Text);
            if (SDT.Rows.Count > 0)
            {

                Session["sid"] = SDT.Rows[0]["sid"].ToString();
                Session["email"] = txtuname.Text;
                Response.Redirect("Student/Default.aspx");
            }
            else
            {
                lbl.Text = "Invalid Credential";
                clean();
            }

        }

    }

    protected void btnfrgt_Click(object sender, EventArgs e)
    {
        if (btnfrgt.Text == "Forgot Password")
        {
            lblEmail.Visible = true;
            txtfrgt.Visible = true;
            btnfrgt.Text = "Send Email";
        }
        else if (btnfrgt.Text == "Send Email")
        {
            if (txtfrgt.Text != "")
            {
                forgotPass();
                //btnfrgt.Text = "Forgot Password";
            }
            else if (txtfrgt.Text == "")
            {
                lbl.Text = "Please, enter the Email";
                txtfrgt.Visible = true;
                lblEmail.Visible = true;
                txtfrgt.Focus();
            }

        }

    }
    public void forgotPass()
    {
        try
        {
            DataSet ds = new DataSet();
            DataSet dss = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT AID, Name, Email, Password FROM AdminMst Where Email= '" + txtfrgt.Text.Trim() + "'", con);
                SqlCommand cmds = new SqlCommand("SELECT SID, StudentName, Email, Password FROM StudentMst Where Email= '" + txtfrgt.Text.Trim() + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                SqlDataAdapter das = new SqlDataAdapter(cmds);
                da.Fill(ds);
                das.Fill(dss);
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress(txtfrgt.Text);
                // Recipient e-mail address.
                Msg.To.Add(txtfrgt.Text);
                Msg.Subject = "Your Password Details";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["Name"] + "<br/><br/>It seems like you forgot you login credentials. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + ds.Tables[0].Rows[0]["Email"] + "<b><br/><b>Your Password: <I>" + ds.Tables[0].Rows[0]["Password"] + "<I><b><br/><br/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                //Msg = null;
                lbl.Text = "Login details sent to Email";
                // Clear the textbox valuess
                btnfrgt.Text = "Forgot Password";
                clean();

            }
            else if (dss.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress(txtfrgt.Text);
                // Recipient e-mail address.
                Msg.To.Add(txtfrgt.Text);
                Msg.Subject = "Your Password Details";
                Msg.Body = "Dear, " + dss.Tables[0].Rows[0]["StudentName"] + "<br/><br/>It seems like you forgot you login credentials. <br/> Please check your Login Details<br/><br/><b>Your Email ID : " + dss.Tables[0].Rows[0]["Email"] + "<b><br/><b>Your Password: <I>" + dss.Tables[0].Rows[0]["Password"] + "<I><b><br/><br/>";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                btnfrgt.Text = "Forgot Password";
                lbl.Text = "Login details sent to Email";
                clean();

            }
            else
            {
                lbl.Text = "The Email you entered not exists.";
                lblEmail.Visible = true;
                txtfrgt.Visible = true;
                btnfrgt.Text = "Send Email";
                txtfrgt.Text = "";
                txtfrgt.Focus();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }
}
