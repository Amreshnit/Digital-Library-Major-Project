﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Publication : System.Web.UI.Page
{
    DS_PUBLICATION.PUBLICATION_SELECTDataTable PubDT = new DS_PUBLICATION.PUBLICATION_SELECTDataTable();
    DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter PubAdapter = new DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter();

    DS_BOOK.BOOK_SELECTDataTable BDT = new DS_BOOK.BOOK_SELECTDataTable();
    DS_BOOKTableAdapters.BOOK_SELECTTableAdapter BAdapter = new DS_BOOKTableAdapters.BOOK_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from PublicationMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            SQLConn.Close();
            if (count > 0)
            {
                PubDT = PubAdapter.Select();
                GridView1.DataSource = PubDT;
                GridView1.DataBind();
            }
            txtpub.Focus();
            (Page.Master.FindControl("btnPub") as Button).Enabled = false;
            (Page.Master.FindControl("btnPub") as Button).BackColor = System.Drawing.Color.DarkOrange;
        }

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        SQLConn.Open();
        SqlCommand cmd = new SqlCommand("select COUNT(*) from PublicationMst where Publication = '" + txtpub.Text + "'", SQLConn);
        int count = Convert.ToInt32(cmd.ExecuteScalar());
        SQLConn.Close();
        if (count == 0)
        {
            PubAdapter.Insert(txtpub.Text);
            lblmsg.Text = "Publisher Saved.";            
        }
        else if (count > 0)
        {
            lblmsg.Text = "This Publisher is already added";
            lblmsg.ForeColor = System.Drawing.Color.Red;
        }
        PubDT = PubAdapter.Select();
        GridView1.DataSource = PubDT;
        GridView1.DataBind();
        txtpub.Text = "";
        txtpub.Focus();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int bid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        PubDT = PubAdapter.Select_By_PID(bid);
        BDT = BAdapter.Select_By_Publication(PubDT.Rows[0]["publication"].ToString());
        if (BDT.Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>window.alert('Publisher cannot be deleted, as it has Books under it.');window.location='Publication.aspx';</script>");
        }
        else
        {
            PubAdapter.Delete(bid);
            lblmsg.Text = "Publisher Deleted";
            PubDT = PubAdapter.Select();
            GridView1.DataSource = PubDT;
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        PubDT = PubAdapter.Select();
        GridView1.DataSource = PubDT;
        GridView1.DataBind();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        PubDT = PubAdapter.Select();
        GridView1.DataSource = PubDT;
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int pid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        TextBox pname = GridView1.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox;


        PubAdapter.Update(pid, pname.Text);
        lblmsg.Text = "Publisher Updated";
        GridView1.EditIndex = -1;
        PubDT = PubAdapter.Select();
        GridView1.DataSource = PubDT;
        GridView1.DataBind();

    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        header();       
    }
    public void header()
    {
        GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
        TableHeaderCell cell = new TableHeaderCell();
        cell.Text = "Publisher List";
        cell.ColumnSpan = 3;
        cell.HorizontalAlign = HorizontalAlign.Center;
        cell.VerticalAlign = VerticalAlign.Middle;
        row.Controls.Add(cell);
        row.BackColor = System.Drawing.ColorTranslator.FromHtml("#000066");
        row.ForeColor = System.Drawing.ColorTranslator.FromHtml("Aqua");
        GridView1.HeaderRow.Parent.Controls.AddAt(0, row);
    }
}