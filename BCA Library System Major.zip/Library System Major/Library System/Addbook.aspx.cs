﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Addbook : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();

    DS_BOOK.BOOK_SELECTDataTable BookDT = new DS_BOOK.BOOK_SELECTDataTable();
    DS_BOOKTableAdapters.BOOK_SELECTTableAdapter BookAdapter = new DS_BOOKTableAdapters.BOOK_SELECTTableAdapter();

    DS_PUBLICATION.PUBLICATION_SELECTDataTable PubDT = new DS_PUBLICATION.PUBLICATION_SELECTDataTable();
    DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter PubAdapter = new DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from BranchMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                lstBoxBrnch.DataSource = BDT;
                lstBoxBrnch.DataTextField = "BranchName";
                lstBoxBrnch.DataValueField = "BranchID";
                lstBoxBrnch.DataBind();
            }
            else if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Branch found, First add Branch.');window.location='Addbranch.aspx';</script>");
            }
            SqlCommand cmd1 = new SqlCommand("select COUNT(*) from PublicationMst", SQLConn);
            int count1 = Convert.ToInt32(cmd1.ExecuteScalar());
            if (count1 > 0)
            {
                PubDT = PubAdapter.Select();
                drppublication.DataSource = PubDT;
                drppublication.DataTextField = "Publication";
                drppublication.DataValueField = "pid";
                drppublication.DataBind();
                drppublication.Items.Insert(0, "-- Select Publisher --");

                (Page.Master.FindControl("btnBook") as Button).Enabled = false;
                (Page.Master.FindControl("btnBook") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }
            else if (count1 == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Publisher found, First add Publisher.');window.location='Publication.aspx';</script>");
            }

            lblmsg.Text = "";
            txtbname.Focus();
        }
    }
    public void clean()
    {
        txtauthor.Text = "";
        txtbname.Text = "";
        txtdetail.Text = "";
        txtprice.Text = "";
        txtqnt.Text = "";
        drppublication.SelectedIndex = 0;
        for (int i = 0; i < lstBoxBrnch.Items.Count; i++)
        {
            if (lstBoxBrnch.Items[i].Selected == true)
            {
                lstBoxBrnch.Items[i].Selected = false;
            }

        }

        txtbname.Focus();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/Book/") + FileUpload1.FileName);

            int a = 0;
            for (int i = 0; i < lstBoxBrnch.Items.Count; i++)
            {
                if (lstBoxBrnch.Items[i].Selected == true && drppublication.SelectedIndex > 0)
                {
                    BookAdapter.Insert(txtbname.Text, txtauthor.Text, txtdetail.Text, Convert.ToDouble(txtprice.Text), drppublication.SelectedItem.Text, lstBoxBrnch.Items[i].Text, Convert.ToInt32(txtqnt.Text), Convert.ToInt32(txtqnt.Text), 0, "~/Book/" + FileUpload1.FileName.ToString());
                    a = 1;
                }
                else if (lstBoxBrnch.Items[i].Selected == false && drppublication.SelectedIndex == 0)
                {
                    lblmsg.Text = "Please, Select Branch & Publisher";

                }
                else if (lstBoxBrnch.Items[i].Selected == false)
                {
                    lblmsg.Text = "Please, Select Branch";
                    lstBoxBrnch.Focus();

                }
                else if (drppublication.SelectedIndex == 0)
                {
                    lblmsg.Text = "Please, Select Publisher";
                    drppublication.Focus();

                }
            }
            if (a == 1)
            {
                lblmsg.Text = "Book saved successfully";
                clean();
            }
        }
        else if (!FileUpload1.HasFile)
        {
            lblmsg.Text = "Please, Select Book Photo";
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        clean();
    }
}