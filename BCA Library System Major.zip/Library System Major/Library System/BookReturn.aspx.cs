﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using paytm;
using System.Data;
using System.Collections.Specialized;

public partial class BookReturn : System.Web.UI.Page
{
    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_PUBLICATION.PUBLICATION_SELECTDataTable PubDT = new DS_PUBLICATION.PUBLICATION_SELECTDataTable();
    DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter PubAdapter = new DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter();
    DS_BOOK.BOOK_SELECTDataTable BookDT = new DS_BOOK.BOOK_SELECTDataTable();
    DS_BOOKTableAdapters.BOOK_SELECTTableAdapter BookAdapter = new DS_BOOKTableAdapters.BOOK_SELECTTableAdapter();
    DS_STUDENT.STUDENT_SELECTDataTable SDT = new DS_STUDENT.STUDENT_SELECTDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter SAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECTTableAdapter();
    DS_RENT.RENT_SELECTDataTable RDT = new DS_RENT.RENT_SELECTDataTable();
    DS_RENTTableAdapters.RENT_SELECTTableAdapter RAdapter = new DS_RENTTableAdapters.RENT_SELECTTableAdapter();

    DS_STUDENT.STUDENT_SELECT_RENT_BOOKDataTable SRDT = new DS_STUDENT.STUDENT_SELECT_RENT_BOOKDataTable();
    DS_STUDENTTableAdapters.STUDENT_SELECT_RENT_BOOKTableAdapter SRAdapter = new DS_STUDENTTableAdapters.STUDENT_SELECT_RENT_BOOKTableAdapter();

    DS_PANALTY.PENALTY_SELECTDataTable PDT = new DS_PANALTY.PENALTY_SELECTDataTable();
    DS_PANALTYTableAdapters.PENALTY_SELECTTableAdapter PAdapter = new DS_PANALTYTableAdapters.PENALTY_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    SqlDataReader myReader = null;


    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        lblbook.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from RentMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Book has been issued to any Student, First issue some Books to Students.');window.location='BookIssue.aspx';</script>");
            }
            else if (count > 0)
            {
                SRDT = SRAdapter.Selecttt(0);
                drppublication.DataSource = SRDT;
                drppublication.DataTextField = "StudentName";
                drppublication.DataValueField = "sid";
                drppublication.DataBind();
                drppublication.Items.Insert(0, "-- Select Student --");
                drpbook.Items.Insert(0, "-- Select Book --");
                (Page.Master.FindControl("btnBookReturn") as Button).Enabled = false;
                (Page.Master.FindControl("btnBookReturn") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }
        }
    }    
    protected void Button12_Click(object sender, EventArgs e)
    {
        if (drppublication.SelectedIndex == 0)
        {

            lblmsg.Text = "Select Student";
            lblmsg.ForeColor = System.Drawing.Color.Red; MultiView1.ActiveViewIndex = -1;
        }
        else if (drpbook.SelectedIndex == 0)
        {
            lblmsg.Text = "Select Book";
            lblmsg.ForeColor = System.Drawing.Color.Red; MultiView1.ActiveViewIndex = -1;
        }
        else
        {
            MultiView1.ActiveViewIndex = 0;
            this.BookDT.Reset();
            BookDT = BookAdapter.Select_By_BNAM(drpbook.SelectedItem.Text);
            ViewState["BBID"] = BookDT.Rows[0]["BookID"].ToString();
            lblbname.Text = BookDT.Rows[0]["Bookname"].ToString();
            lblauthor.Text = BookDT.Rows[0]["author"].ToString();
            lblbran.Text = BookDT.Rows[0]["branch"].ToString();
            lblpub.Text = BookDT.Rows[0]["publication"].ToString();
            lblprice.Text = BookDT.Rows[0]["price"].ToString();

            Image2.ImageUrl = BookDT.Rows[0]["Image"].ToString();

            SDT = SAdapter.Select_By_SID(Convert.ToInt32(drppublication.SelectedValue));
            lblstudent.Text = SDT.Rows[0]["Studentname"].ToString();

            RDT = RAdapter.Select_SID_BName_Status(drpbook.SelectedItem.Text, Convert.ToInt32(drppublication.SelectedValue), 0);
            lbldays.Text = RDT.Rows[0]["Days"].ToString();
            lblidate.Text = RDT.Rows[0]["IssueDate"].ToString();
            ViewState["RRID"] = RDT.Rows[0]["rid"].ToString();


            DateTime finalreturndate, currentdate;
            finalreturndate = Convert.ToDateTime(lblidate.Text).AddDays(Convert.ToInt32(lbldays.Text));
            currentdate = System.DateTime.Now;

           // TimeSpan diffrence = (currentdate - finalreturndate);       

            //  int iday = Convert.ToDateTime(RDT.Rows[0]["IssueDate"].ToString()).Day;
            //   int rday = System.DateTime.Now.Day;
            //  int pday = rday - iday;
            //  pday = 1 + pday - Convert.ToInt32(lbldays.Text);

            if (finalreturndate < currentdate)
            {
                
                SQLConn.Open();
                SqlCommand myCommand = new SqlCommand("select count(*) from rentmst where rid = "+ Convert.ToInt32(RDT.Rows[0]["rid"].ToString()) +" and penalty = 'Paid'", SQLConn);
                int count = Convert.ToInt32(myCommand.ExecuteScalar());
                string mainstring, dd, mm, yyyy;
                mainstring = Convert.ToString(finalreturndate);
                dd = mainstring.Substring(0, 2);
                mm = mainstring.Substring(3, 2);
                yyyy = mainstring.Substring(6, 4);
                mainstring = yyyy + "-" + mm + "-" + dd;         

              SqlCommand cmdDay = new SqlCommand("select DATEDIFF(day, '"+mainstring+"', GETDATE())", SQLConn);
              int NoDays = Convert.ToInt32(cmdDay.ExecuteScalar());

                SQLConn.Close();
                if (count  == 0)
                {
                    lblpanalty.Text = "Yes";
                }
                else if (count == 1)
                {
                    lblpanalty.Text = "Penalty Paid";
                }

                lblAMt.Text = Convert.ToString(Convert.ToInt32(NoDays) * 10);              
            }
            else

            {
                lblpanalty.Text = "No";
            }
        }
    }
    protected void drppublication_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drppublication.SelectedValue != "-- Select Student --")
        {
            RDT = RAdapter.SelectBook_by_sid_and_status(Convert.ToInt32(drppublication.SelectedValue), 0);
            drpbook.DataSource = RDT;
            drpbook.DataTextField = "Bookname";
            drpbook.DataValueField = "rid";
            drpbook.DataBind();
            drpbook.Items.Insert(0, "-- Select Book --");
        }
    }
   
    public void emailNsms()
    {
        try
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT StudentName, BranchName, Mobile, Email FROM StudentMst Where SID = '" + drppublication.SelectedValue + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                System.Net.Mail.MailMessage Msg = new System.Net.Mail.MailMessage();
                // Sender e-mail address.
                Msg.From = new System.Net.Mail.MailAddress("bcaproject.service@gmail.com");
                // Recipient e-mail address.
                Msg.To.Add(ds.Tables[0].Rows[0]["Email"].ToString());
                Msg.Subject = "LMS Penalty Details";
                Msg.Body = "Dear, " + ds.Tables[0].Rows[0]["StudentName"] + ", <br/><br/>Your library penalty details are as follows:- <br/><br/> Book Name :- " + lblbname.Text + "<br/> Issue Date :- " + lblidate.Text + "<br/> Fine for :- " + Convert.ToInt32(lblAMt.Text)/10 + " days <br/> Penalty Amount :- RS." + lblAMt.Text + "/-<br/> <br/> Clear the due today, to avoid additional charges. <br/> Regards LMS";
                Msg.IsBodyHtml = true;
                // your remote SMTP server IP.
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("bcaproject.service@gmail.com", "9163029676");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

                //sms
                string destination = "91" + ds.Tables[0].Rows[0]["Mobile"].ToString();
                string message = "Dear, " + ds.Tables[0].Rows[0]["StudentName"] + ", Your have been charged a fine of Rs. " + lblAMt.Text + "/-, for " + Convert.ToInt32(lblAMt.Text)/10 + " days. Clear the due today, to avoid additional charges. Regards LMS";
                String message1 = HttpUtility.UrlEncode(message);

                //Send message
                using (var wb = new System.Net.WebClient())
                {
                    byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "g2GFKqrniF4-jLt5tSvpDpSS0GOOl24IAKHO3tsHD0"},
                {"numbers" , destination},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
                    string result = System.Text.Encoding.UTF8.GetString(response);

                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("{0} Exception caught.", ex);
        }
    }

    protected void btnreturnbook_Click(object sender, EventArgs e)
    {
        SqlCommand command;
        SqlDataAdapter adapter = new SqlDataAdapter();
        String sql = "";
        if (lblpanalty.Text == "Yes")
        {
            Random r = new Random();
            int tranid = r.Next(10000, 99999);
            string tid = "T" + Convert.ToString(tranid);
            Session["orderid"] = tid;

            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(entrydate) from PenaltyMst where convert (varchar(10), entrydate, 103) != CONVERT(varchar(10), GETDATE(), 103) and SID = " +drppublication.SelectedValue, SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            PDT = PAdapter.Select_by_SID_Bookname(Convert.ToInt32(drppublication.SelectedValue), lblbname.Text);

            if (PDT.Rows.Count == 0 && count == 0)
            {
                sql = "INSERT INTO [PenaltyMst] ([SID],[BookName],[Price],[panalty],[EntryDate],[Status],[Tran_ID]) VALUES ('" + drppublication.SelectedValue + "', '" + lblbname.Text + "','" + Convert.ToDouble(lblprice.Text) + "', '" + Convert.ToDouble(lblAMt.Text) + "', GETDATE(), '0', '" + tid + "')";
                command = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand.ExecuteNonQuery();
              
                emailNsms();
                lblmsg.Text = "Penalty data has been generated, first clear the penalty then return book. Your Penalty Amount is Rs." + lblAMt.Text;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Visible = true;
              //  sql = "update PenaltyMst set status = 0, Tran_ID = '"+tid+"' where Tran_ID = NULL and  SID = " + drppublication.SelectedValue;
              //  command = new SqlCommand(sql, SQLConn);
             //   adapter.InsertCommand = new SqlCommand(sql, SQLConn);
              //  adapter.InsertCommand.ExecuteNonQuery();
            }
            else if (PDT.Rows.Count > 0 && count > 0)
            {               

                sql = "update PenaltyMst set panalty = " +lblAMt.Text+ ", entrydate = GETDATE() where status = 0 and Tran_ID IS NOT NULL and SID = " + drppublication.SelectedValue;
                command = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand = new SqlCommand(sql, SQLConn);
                adapter.InsertCommand.ExecuteNonQuery();
                emailNsms();
                lblmsg.Text = "Penalty data has been Re-generated. Your New Penalty Amount is Rs." + lblAMt.Text;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Visible = true;
            }
            else
            {
                lblmsg.Text = "Already penalty data has been generated today. Re-generation will be done tommorow";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Visible = true;
            }
                    
            SRDT = SRAdapter.Selecttt(0);
            drppublication.DataSource = SRDT;
            drppublication.DataTextField = "StudentName";
            drppublication.DataValueField = "sid";
            drppublication.DataBind();
            drppublication.Items.Insert(0, "-- Select Student --");
            drpbook.SelectedIndex = 0;
            MultiView1.ActiveViewIndex = -1;
           
        }
        else if (lblpanalty.Text == "No" || lblpanalty.Text == "Penalty Paid")
        {
            RAdapter.RENT_SELECT_RETURN(Convert.ToInt32(ViewState["RRID"].ToString()), 1, Convert.ToInt32(ViewState["BBID"].ToString()));
            lblmsg.Text = "Book Returned Successfully";
            lblmsg.ForeColor = System.Drawing.Color.Blue;
            lblmsg.Visible = true;
            SRDT = SRAdapter.Selecttt(0);
            drppublication.DataSource = SRDT;
            drppublication.DataTextField = "StudentName";
            drppublication.DataValueField = "sid";
            drppublication.DataBind();
            drppublication.Items.Insert(0, "-- Select Student --");
            drpbook.SelectedIndex = 0;
            MultiView1.ActiveViewIndex = -1;
        }
    }
}
   
