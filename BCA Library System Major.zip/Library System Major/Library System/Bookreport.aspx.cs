﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class bookreport : System.Web.UI.Page
{
    DS_PUBLICATION.PUBLICATION_SELECTDataTable PubDT = new DS_PUBLICATION.PUBLICATION_SELECTDataTable();
    DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter PubAdapter = new DS_PUBLICATIONTableAdapters.PUBLICATION_SELECTTableAdapter();

    DS_BRANCH.BRANCH_SELECTDataTable BDT = new DS_BRANCH.BRANCH_SELECTDataTable();
    DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter BAdapter = new DS_BRANCHTableAdapters.BRANCH_SELECTTableAdapter();
    DS_BOOK.BOOK_SELECTDataTable BookDT = new DS_BOOK.BOOK_SELECTDataTable();
    DS_BOOKTableAdapters.BOOK_SELECTTableAdapter BookAdapter = new DS_BOOKTableAdapters.BOOK_SELECTTableAdapter();
    SqlConnection SQLConn = new SqlConnection("Data Source=.;Initial Catalog=LibrarySystem;Integrated Security=True");
    string bookname;
    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        lblmsg0.Text = "";
        if (Page.IsPostBack == false)
        {
            SQLConn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from BookMst", SQLConn);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count == 0)
            {
                Response.Write("<script language='javascript'>window.alert('No Book found, First add Book.');window.location='Addbook.aspx';</script>");
            }
            else if (count > 0)
            {
                BDT = BAdapter.SelectBranch();
                drpbranch.DataSource = BDT;
                drpbranch.DataTextField = "Branchname";
                drpbranch.DataValueField = "Branchid";
                drpbranch.DataBind();
                drpbranch.Items.Insert(0, " -- Select Branch --");
                MultiView1.ActiveViewIndex = -1;

                PubDT = PubAdapter.Select();
                drppublication.DataSource = PubDT;
                drppublication.DataTextField = "Publication";
                drppublication.DataValueField = "pid";
                drppublication.DataBind();
                drppublication.Items.Insert(0, "-- Select Publisher --");

                (Page.Master.FindControl("btnBookRpt") as Button).Enabled = false;
                (Page.Master.FindControl("btnBookRpt") as Button).BackColor = System.Drawing.Color.DarkOrange;
            }

        }
    }
    protected void btnviewbranch_Click(object sender, EventArgs e)
    {
        if (drpbranch.SelectedIndex == 0)
        {
            lblmsg.Text = "Select Branch";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            GridView1.DataSource = null;
            GridView1.DataBind();
            MultiView1.ActiveViewIndex = -1;
        }
        else
        {
            this.BookDT.Reset();
            BookDT = BookAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
            GridView1.DataSource = BookDT;
            GridView1.DataBind();
            lblmsg0.Text = GridView1.Rows.Count.ToString() + " - Records Found";

            MultiView1.ActiveViewIndex = 0;
            drppublication.SelectedIndex = 0;
        }
    }
    protected void btnviewpublication_Click(object sender, EventArgs e)
    {
        if (drppublication.SelectedIndex == 0)
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            lblmsg.Text = "Select Publication";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            MultiView1.ActiveViewIndex = -1;
        }
        else
        {
            MultiView1.ActiveViewIndex = 0;
            this.BookDT.Reset();
            BookDT = BookAdapter.Select_By_Publication(drppublication.SelectedItem.Text);
            if (BookDT.Rows.Count > 0)
            {
                GridView1.DataSource = BookDT;
                GridView1.DataBind();
                lblmsg0.Text = GridView1.Rows.Count.ToString() + " - Records Found";
                drpbranch.SelectedIndex = 0;
            }
        }
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
        BookDT = BookAdapter.Select_BY_BID(Convert.ToInt32(e.CommandArgument.ToString()));
        Session["BookID"] = BookDT.Rows[0]["BookID"].ToString();
        Session["BookName"] = BookDT.Rows[0]["Bookname"].ToString();
        lblbname.Text = BookDT.Rows[0]["Bookname"].ToString();
        lblauthor.Text = BookDT.Rows[0]["author"].ToString();
        lblbran.Text = BookDT.Rows[0]["branch"].ToString();
        lblpub.Text = BookDT.Rows[0]["publication"].ToString();
        lblprice.Text = BookDT.Rows[0]["price"].ToString();
        lblqnt.Text = BookDT.Rows[0]["Quantities"].ToString();
        lblaqnt.Text = BookDT.Rows[0]["availableqnt"].ToString();
        lblrqnt.Text = BookDT.Rows[0]["rentqnt"].ToString();
        lbldetail.Text = BookDT.Rows[0]["Detail"].ToString();
        Image2.ImageUrl = BookDT.Rows[0]["Image"].ToString();

        if (lblrqnt.Text == "0")
        {
            btndlt.Enabled = true;
            lbl.Visible = false;
        }
        else if (lblrqnt.Text != "0")
        {
            btndlt.Enabled = false;
            lbl.Text = "This book cannot be deleted, as the Rent out Quantity is '" + lblrqnt.Text + "'";
            lbl.Visible = true;
        }

    }
    protected void btndlt_Click(object sender, EventArgs e)
    {
        if (btndlt.Enabled == true)
        {
            string qry = "DELETE FROM bookmst where rentqnt = 0 and bookid = " + Session["BookID"].ToString();
            SQLConn.Open();
            SqlCommand com = new SqlCommand(qry, SQLConn);
            com.ExecuteNonQuery();
            SQLConn.Close();

            if (drpbranch.SelectedIndex > 0)
            {
                BookDT = BookAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
                GridView1.DataSource = BookDT;
                GridView1.DataBind();
                MultiView1.ActiveViewIndex = 0;
            }
            else if (drppublication.SelectedIndex > 0)
            {
                MultiView1.ActiveViewIndex = 0;
                BookDT = BookAdapter.Select_By_Publication(drppublication.SelectedItem.Text);
                GridView1.DataSource = BookDT;
                GridView1.DataBind();
            }          
          
            lblmsg.Text = "'" + Session["BookName"].ToString() + "' has been deleted";
            Session["BookName"] = null;
            Session["BookID"] = null;
        }      
                    
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {       
            txtAuhtorName.Visible = true;
            txtBookName.Visible = true;
            txtDetails.Visible = true;
            txtPrice.Visible = true;
            txtQty.Visible = true;
            btnUpdate.Visible = true;

            lblauthor.Visible = false;
            lblbname.Visible = false;
            lbldetail.Visible = false;
            lblprice.Visible = false;
            lblqnt.Visible = false;
            btnEdit.Visible = false;

            txtAuhtorName.Text = lblauthor.Text;
            txtBookName.Text = lblbname.Text;
            txtDetails.Text = lbldetail.Text;
            txtPrice.Text = lblprice.Text;
            txtQty.Text = lblqnt.Text;            
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(lblrqnt.Text) > Convert.ToInt32(txtQty.Text))
        {
            Response.Write("<script language='javascript'>window.alert('Total number of book has to be atleast equal to Rent out book/s');</script>");
          
        }
        else if (Convert.ToInt32(lblrqnt.Text) <= Convert.ToInt32(txtQty.Text))
        {
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            String sql = "";
            SQLConn.Open();
            sql = "update BookMst set bookname = '" + txtBookName.Text + "', author = '" + txtAuhtorName.Text + "', detail = '" + txtDetails.Text + "', price = '" + txtPrice.Text + "', Quantities = " + txtQty.Text + " where bookname = '" + lblbname.Text + "'";
            command = new SqlCommand(sql, SQLConn);
            adapter.InsertCommand = new SqlCommand(sql, SQLConn);
            adapter.InsertCommand.ExecuteNonQuery();

            lblmsg.Text = "Data updated, succesfully.";
            lblmsg.ForeColor = System.Drawing.Color.Blue;
            lblmsg.Visible = true;


            txtAuhtorName.Visible = false;
            txtBookName.Visible = false;
            txtDetails.Visible = false;
            txtPrice.Visible = false;
            txtQty.Visible = false;
            btnEdit.Visible = true;

            lblauthor.Visible = true;
            lblbname.Visible = true;
            lbldetail.Visible = true;
            lblprice.Visible = true;
            lblqnt.Visible = true;
            btnUpdate.Visible = false;

            if (drpbranch.SelectedIndex != 0)
            {
                this.BookDT.Reset();
                BookDT = BookAdapter.Select_By_Branch(drpbranch.SelectedItem.Text);
                GridView1.DataSource = BookDT;
                GridView1.DataBind();
            }
            if (drppublication.SelectedIndex != 0)
            {
                BookDT = BookAdapter.Select_By_Publication(drppublication.SelectedItem.Text);
                GridView1.DataSource = BookDT;
                GridView1.DataBind();
            }
            MultiView1.ActiveViewIndex = 0;
        }
    }
}